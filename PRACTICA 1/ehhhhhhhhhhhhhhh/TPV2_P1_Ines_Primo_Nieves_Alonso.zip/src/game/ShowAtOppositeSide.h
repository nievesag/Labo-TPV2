#pragma once

#include "../game/PhysicsComponent.h"

class ShowAtOppositeSide : public PhysicsComponent
{

public:

	ShowAtOppositeSide();
	~ShowAtOppositeSide();
	void update(Container* o);
	

private:

};
